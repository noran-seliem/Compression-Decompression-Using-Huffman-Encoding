#include <iostream> 
#include <iterator> 
#include <map> 
using namespace std;

std::map<int , int> frequency_count;
//using pgm vector=vectr
for(int i = 0; i < vectr.size(); i++)
{
    frequency_count[vectr[i]]++;
}
for(map<int,int>:: iterator it = frequency_count.begin(); it != frequency_count.end(); it++)
{
    cout<<it->first<<" "<<it->second<<endl;
}
int freq[100];
for(int i=0; i<100 ; i++)
{
    freq[i]=frequency_count.at(i);
}