#include <iostream> 
#include <iterator> 
#include <map> 
using namespace std;
int main(){
map<char, int> freq_table ;
//using pgm vector=vectr

for (int i = 0; i < vectr.size(); i++)
{
    freq_table[vectr[i]]++;

}
for(map<int,int>:: iterator it= freq_table.begin(); it != freq_table.end(); it++)
{
    cout<<it->first<<" "<<it->second<<endl;
}
}

// CPP program to count frequencies of array items 
#include <bits/stdc++.h> 
using namespace std; 
  
void countFreq(int arr[], int n) 
{ 
    unordered_map<int, int> mp; 
  
    // Traverse through array elements and 
    // count frequencies 
    for (int i = 0; i < n; i++) 
        mp[arr[i]]++; 
  
    // Traverse through map and print frequencies 
    for (auto x : mp) 
        cout << x.first << " " << x.second << endl; 
} 
  
int main() 
{ 
    int arr[] = { 10, 20, 20, 10, 10, 20, 5, 20 }; 
    int n = sizeof(arr) / sizeof(arr[0]); 
    countFreq(arr, n); 
    return 0; 
}