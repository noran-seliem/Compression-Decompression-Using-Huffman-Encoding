clear
g++ -c src/imageprocessing.cpp -o src/imageprocessing.o
g++ -c main.cpp -o main.o
g++ -o main main.o src/imageprocessing.o
./main NORMAL2-IM-1437-0001.pgm  TRY.pgm 