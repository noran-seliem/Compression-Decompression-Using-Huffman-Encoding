#include <iostream>
#include <string>
#include <fstream>
#include <sstream> 
#include <bits/stdc++.h> 
using namespace std;

/*---------------READ IMAGE--------------------------------*/
void ReadImage(char fname[], int ***fimage, int& M, int& N, int& Q)
{
    int i, j;
    char d;

    char header [100], *ptr;
    ifstream ifp;

    ifp.open(fname, ios::binary);

    if (!ifp)
    {
        cout << "Can't read image: <" << fname << '>' << endl;
        void getch();
        exit(1);
    }

    ifp.getline(header,100,'\n');
    if((header[0]!='P') || header[1]!='5')   /* 'P5' Format */
    {
        cout << "Image <" << fname << "> is not in binary PGM 'P5' format." << endl;
        void getch();
        exit(1);
    }

    ifp.getline(header,100,'\n');
    while(header[0]=='#')
        ifp.getline(header,100,'\n');

    M=strtol(header,&ptr,0);
    N=atoi(ptr);

    ifp.getline(header,100,'\n');

    Q=strtol(header,&ptr,0);

  *fimage = new int* [N];
    for(i=0; i<N; i++)
        (*fimage)[i] = new int[M];

    for(i=0; i<N; i++)
    {
        for(j=0; j<M; j++)
        {
            d = ifp.get();
            (*fimage)[i][j]= (int)d;
            cout <<j;
        }
        cout <<i;
        }
    }

  
int main()
{
    int i, j;
    int N, M, Q;        // N=Rows   M=Cols   Q=GreyLevels
    int **fimage;       // int **I 2-D Array of Image
    char infile[40];        // name of input file
    char outfile[40];   // name of output image file

    cout << "Enter name of *.pgm INPUT image file: ? ";
    cin  >> infile;
    cout << i<<endl;
    cout <<j<<endl;

    ReadImage(infile, &fimage, M, N, Q);    // Memory created for fimage
}