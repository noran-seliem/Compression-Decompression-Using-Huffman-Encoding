#include <iostream>
#include <cstdlib>
#include <cstdio>
#include<vector>
#include <bits/stdc++.h> 
#include <iterator> 
#include <map> 

#define FALSE 0;
#define TRUE 1;

using namespace std;

int numberOfColumns, numberOfRows, numberOfBands, highVal, totalPixels, header;
unsigned char *image;


void readImage(){
	FILE * fpIn;
	char * string;
	int doneReading = FALSE;
	char c;

	fpIn = fopen("NORMAL2-IM-1427-0001.pgm", "rb");
	if(fpIn == NULL){
		cerr<<"Such a file does not exist...";
		exit;
	}
	string = (char *) calloc(256,1);
	while(!doneReading && (c = (char) fgetc(fpIn)) != '\0')
		switch(c){
			case 'P':
				c = (char) fgetc(fpIn);
				switch(c){
					case '2':
						header = 2;
						numberOfBands = 1;
						//pgm plain
					break;
					case '5':
						header = 5;
						numberOfBands = 1;
						//pgm Normal
					break;
					case '3':
						header = 3;
						numberOfBands = 3;
						//ppm plain
					break;
					case '6':
						header = 6;
						numberOfBands = 3;
						//ppm Normal
					break;
				}
				c = (char) fgetc(fpIn);
				if(c != 0x0A){
					ungetc(c, fpIn);
				}
				else{
					ungetc(c, fpIn);
					fgets(string, 256, fpIn);
				}
			break;
			case '#':
			fgets(string, 256, fpIn);
			cout<<"File you entered is "<<string<<"\n";
			break;
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				ungetc(c, fpIn);
				fscanf(fpIn,"%d %d %d", &(numberOfColumns), &(numberOfRows), &(highVal));
				doneReading = TRUE;
				fgetc(fpIn);
			break;
		}
	totalPixels = numberOfRows * numberOfColumns * numberOfBands;
	image = (unsigned char *) malloc ( totalPixels);
	fread( image,1, totalPixels,fpIn);
	cout<<"Reading the image "<<" was sucessfull...\n";
	
	cout<<"Wrote the image into "<<"...\n";
	for (int i = 0; i <  numberOfRows; i++) {
      for (int j = 0; j < numberOfColumns; j++) 
    	{
			char c= (unsigned char) *(image + i*numberOfColumns + j);
         	printf("%c", c); 

 map<char, int> freq_table ;
//using pgm vector=vectr

for (int i = 0; i < vectr.size(); i++)
{
    freq_table[vectr[i]]++;

}
for(map<int,int>:: iterator it= freq_table.begin(); it != freq_table.end(); it++)
{
    cout<<it->first<<" "<<it->second<<endl;
}
		}

	}
    
}

void writeImage(){
	FILE * fpOut;

	fpOut = fopen("Image2.pgm", "wb");
	if(fpOut == NULL){
		cerr<<"Error couldn't write the image "<<"...\n";
		exit;
	}
	fprintf(fpOut, "P%d\n%d %d\n%d\n", header, numberOfColumns, numberOfRows, highVal );
	vector<char> v;
	for (int i = 0; i <  numberOfRows; i++) {
      for (int j = 0; j < numberOfColumns; j++) 
    	{
			char c= (unsigned char) *(image + i*numberOfColumns + j);
			fprintf(fpOut, "%c", c); 
			char s = c ;
			  v.push_back(s);
    	
        }
	}

	cout<<"Wrote the image into "<<"...\n";
}

int main()
{
	readImage();
	writeImage();
	return 0;
}
