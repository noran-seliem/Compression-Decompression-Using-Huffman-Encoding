#include<iostream>
#include<queue>
#include <map> 
#include <iterator> 
using namespace std; 
#define MAX_SIZE 1000

void frequancy (unsigned char data[], map<unsigned char, int> &freq_table )
{
    for (int i = 0; i <(sizeof(data)/sizeof(data[0])); i++)
    {
        freq_table[data[i]]++;
    }
}



class Tree_node { 
public: 
    unsigned char data; 
    int freq; 
      Tree_node* left; 
      Tree_node* right; 
      Tree_node( unsigned char Data, int frequency) 
    {  data = Data; 
        freq = frequency; 
        left = right =0; 
    } 
}; 
class Comparison { 
public: 
    bool operator() (Tree_node* a, Tree_node* b)  
    { 
        return a->freq > b->freq; 
    } 
};
Tree_node* build_Tree(priority_queue<Tree_node*,vector<Tree_node*>, Comparison> pq) 
{ 
    while (pq.size() != 1)
     { 
        Tree_node* left = pq.top();  pq.pop(); 
        Tree_node* right = pq.top(); pq.pop(); 
        Tree_node* node = new Tree_node('$', left->freq + right->freq); 
        node->left = left; 
        node->right = right; 
        pq.push(node); 
    } 
    return pq.top(); 
} 
void print_Code(Tree_node* root, int arr[], int top) 
{ 
    if (root->left) 
    { 
        arr[top] = 0; 
        print_Code(root->left, arr, top + 1); 
    }
    if (root->right) { 
        arr[top] = 1; 
        print_Code(root->right, arr, top + 1); 
    } 
    if (!root->left && !root->right)
     { 
        cout << root->data << " "; 
        for (int i = 0; i < top; i++) { 
            cout << arr[i]; 
        } 
        cout << endl; 
    } 
} 

void Huffman_Code( map< unsigned char, int> freq_table) 
{  
    map<unsigned char, int>::iterator it; 
    priority_queue<Tree_node*, vector<Tree_node*>,Comparison> pq;  
    for (it = freq_table.begin(); it != freq_table.end(); it++) 
    { 
    Tree_node* newNode = new Tree_node(it->first, it->second); 
        pq.push(newNode); 
    } 
    Tree_node* root = build_Tree(pq); 
    int arr[MAX_SIZE], top = 0; 
    print_Code(root, arr, top); 
} 
void print_code_table();

int encode(unsigned char &data[],int *encoded_msg[])
 {
     for(int i = 0, i<( sizeof(data)/sizeof(data[0])), i++) 
     {
        encoded_msg[i] = table[data[i]];
     }
    return ( sizeof(encoded_msg)/sizeof(encoded_msg[0]));
 }